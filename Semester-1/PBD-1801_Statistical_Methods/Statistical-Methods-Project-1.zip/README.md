# 📊 Project 1 – Exploratory Data Analysis using R

**Subject:** PBD-1801 Statistical Methods  
**Semester:** 1  
**Tool Used:** R Programming

---

## 📌 Objective

To perform Exploratory Data Analysis (EDA) on a sample retail dataset.  
Key tasks include data cleaning, statistical summaries, and visualizing key variables.

---

## 🧠 Key Concepts Applied

- Data Cleaning and Missing Value Handling
- Frequency Tables and Descriptive Statistics
- Box Plots, Histograms, and Correlation Matrix
- Summary Statistics (mean, median, variance, etc.)
- Outlier Detection using IQR

---

## 📂 Folder Structure

- `code/` – R scripts for EDA and plotting
- `data/` – Sample CSV dataset
- `output/plots/` – Generated plots (histogram, boxplot, etc.)
- `report/` – PDF report with analysis summary
- `notes.md` – Key theoretical notes from subject
- `What_I_Learned.md` – Summary of personal learning from the project

---

## 📷 Sample Outputs

<img src="output/plots/histogram.png" width="400"/>  
<img src="output/plots/boxplot.png" width="400"/>

---

## ✅ Status

✔️ Completed – Ready for review and submission  
📅 Date: [Your Date]

---

## 📬 Contact

For queries or collaborations:  
**Name:** Mauli Patel  
**LinkedIn:** [linkedin.com/in/itsmemauliii](https://www.linkedin.com/in/itsmemauliii)
