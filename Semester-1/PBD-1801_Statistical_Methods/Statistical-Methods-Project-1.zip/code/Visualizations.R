# Visualizations.R

# Additional plots
ggplot(data, aes(x = Category, y = Sales)) +
  geom_boxplot(fill = "purple")

# Correlation plot
cor_matrix <- cor(data[sapply(data, is.numeric)], use = "complete.obs")
print(cor_matrix)
