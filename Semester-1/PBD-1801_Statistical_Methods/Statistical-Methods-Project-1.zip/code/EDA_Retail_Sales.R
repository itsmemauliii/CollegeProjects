# EDA_Retail_Sales.R

# Load libraries
library(tidyverse)

# Load data
data <- read.csv("data/sample_dataset.csv")

# Summary statistics
summary(data)

# Histogram
ggplot(data, aes(x = Sales)) + 
  geom_histogram(binwidth = 10, fill = "blue", color = "black")

# Boxplot
ggplot(data, aes(y = Sales)) + 
  geom_boxplot(fill = "orange")

# Save plots manually or via ggsave()
