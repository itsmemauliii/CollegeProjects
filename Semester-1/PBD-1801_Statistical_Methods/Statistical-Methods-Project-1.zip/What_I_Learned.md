# 📘 What I Learned – Project 1: EDA using R

This project helped me understand how to:
- Perform data cleaning and handle missing values
- Use summary statistics to describe data
- Visualize distributions using box plots and histograms
- Identify outliers using IQR
- Apply correlation and interpret simple trends in data

Tool: R Programming
