# 📒 Statistical Methods – Key Concepts (Condensed Notes)

- Descriptive Statistics: Mean, Median, Mode, Variance, SD
- Visualization: Boxplot, Histogram, Scatterplot
- Correlation & Regression
- Categorical Data: Chi-square tests
- Time Series: Trend, Seasonality, ACF

Packages: ggplot2, dplyr, readr, tidyr, stats
